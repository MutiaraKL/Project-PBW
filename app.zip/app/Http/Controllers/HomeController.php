<?php
  
namespace App\Http\Controllers;
  
use Illuminate\Http\Request;
use Illuminate\View\View;
use Illuminate\Support\Facades\Auth;
use App\Models\Queue; 
use Illuminate\Support\Facades\Hash;
use App\Models\User; 
use App\Models\QueueSetting;
use App\Models\Printers; 
use Illuminate\Support\Facades\DB;

class HomeController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }
  
    public function userHome(): View
    {
        return view('userHome');
    } 
  
    public function adminHome()
    {
        $totalAntrean = Queue::count();
        $totalLoket = QueueSetting::count();
        $totalPengguna = User::count();

        return view('adminHome', compact('totalAntrean', 'totalLoket', 'totalPengguna'));
    }
  
    public function managerHome(): View
    {
        return view('managerHome');
    }


    //halaman untuk admin
    public function adminContact()
    {
        return view('adminContact');
    }

    public function resetQueue()
    {
        // Disable foreign key checks
        DB::statement('SET FOREIGN_KEY_CHECKS=0;');

        // Truncate the queue table
        Queue::truncate();

        // Re-enable foreign key checks
        DB::statement('SET FOREIGN_KEY_CHECKS=1;');

        // Redirect back with a success message
        return redirect()->back()->with('success', 'Antrian telah direset');
    }

    public function antarmukaDisplay()
    {
        return view('antarmukaDisplay');
    }

    public function printQueue(Request $request)
    {
        $jenisTransaksi = $request->input('jenis_transaksi');
        $lastQueue = Queue::where('jenis_transaksi', $jenisTransaksi)->latest()->first();
        $nomorAwal = ($jenisTransaksi === 'JKN/BPJS') ? 'B' : 'A';

        if ($lastQueue) {
            $lastQueueNumber = $lastQueue->nomor_antrean;
            $lastNumber = intval(substr($lastQueueNumber, 1));
            $nextNumber = $lastNumber + 1;
            $nextQueueNumber = $nomorAwal . str_pad($nextNumber, 3, '0', STR_PAD_LEFT);
            $nomorLoket = ($jenisTransaksi === 'JKN/BPJS' && substr($lastQueueNumber, 0, 1) === 'B') ? '4' : '3';
        } else {
            $nextQueueNumber = $nomorAwal . '001';
            $nomorLoket = ($jenisTransaksi === 'JKN/BPJS') ? '2' : '1';
        }

        Queue::create([
            'nomor_antrean' => $nextQueueNumber,
            'nomor_loket' => $nomorLoket,
            'jenis_transaksi' => $jenisTransaksi,
            'status' => 'pending',
        ]);

        return redirect()->back()->with('success', 'Antrian telah dicetak');
    }

    public function callQueue(Queue $queue) {
        // Simpan log pemanggilan antrean
        $log = new QueueCallLog();
        $log->queue_id = $queue->id;
        $log->called_by = Auth::id();
        $log->save();

        // Ubah status antrean menjadi "active"
        $queue->status = 'active';
        $queue->save();

        return response()->json(['message' => 'Antrean berhasil dipanggil']);
    }

    public function repeatCall() {
        // Ambil antrean terakhir yang dipanggil
        $lastCall = QueueCallLog::latest()->first();

        if ($lastCall) {
            // Ubah status antrean terakhir menjadi "active" jika belum aktif
            $queue = $lastCall->queue;
            if ($queue->status !== 'active') {
                $queue->status = 'active';
                $queue->save();
            }

            // Simpan log pemanggilan ulang
            $log = new QueueCallLog();
            $log->queue_id = $queue->id;
            $log->called_by = Auth::id();
            $log->save();

            return response()->json(['message' => 'Pemanggilan antrean berhasil diulangi']);
        }

        return response()->json(['message' => 'Tidak ada antrean yang dipanggil sebelumnya']);
    }
    
    public function antarmukaAntrean()
    {
        return view('antarmukaAntrean');
    }

    public function adminProfile()
    {
        $user = Auth::user();
        return view('adminProfile', compact('user'));
    }

    public function adminUploadPhoto(Request $request)
    {
        $request->validate([
            'photo' => 'required|image|mimes:jpeg,png,jpg,gif|max:2048',
        ]);

        // Simpan foto di direktori yang ditentukan
        $imageName = time().'.'.$request->photo->extension();  
        $request->photo->move(public_path('profile_photos'), $imageName);

        // Simpan nama foto ke database
        $user = Auth::user();
        $user->photo = $imageName;
        $user->save();

        return redirect()->back()->with('success','Photo uploaded successfully.');
    }

    public function adminEditPassword(Request $request)
    {
        $user = auth()->user();

        // Validasi input dari form
        $request->validate([
            'current_password' => 'required',
            'new_password' => 'required|min:6|different:current_password',
            'confirm_password' => 'required|same:new_password',
        ]);

        // Memeriksa apakah password saat ini benar
        if (!Hash::check($request->current_password, $user->password)) {
            return redirect()->back()->with('error', 'Password saat ini tidak cocok.');
        }

        // Menyimpan password baru ke dalam database
        $user->password = Hash::make($request->new_password);
        $user->save();

        return redirect()->back()->with('success', 'Password berhasil diubah.');
    }
    
    public function loketDetails(): View
    {
        $activeQueues = Queue::where('status', 'active')->get();
        $queuesNotCalled = Queue::where('status', 'pending')->get();
        $user = Auth::user();
        return view('loketdetails', compact('activeQueues', 'queuesNotCalled', 'user'));
    }

    public function usersIndex()
    {
        $users = User::all();
        return view('usersIndex', compact('users'));
    }

    public function addUsersIndex()
    {
        return view('addUsersIndex');
    }

    public function storeUser(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|string|email|max:255|unique:users',
            'password' => 'required|string|min:8|confirmed',
        ]);

        User::create([
            'name' => $request->name,
            'email' => $request->email,
            'password' => Hash::make($request->password),
        ]);

        return redirect()->route('users.index');
    }

    public function editUsersIndex($id)
    {
        $user = User::findOrFail($id);
        return view('editUsersIndex', compact('user'));
    }

    public function updateUser(Request $request, $id)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|string|email|max:255|unique:users,email,'.$id,
            'password' => 'nullable|string|min:8|confirmed',
        ]);

        $user = User::findOrFail($id);
        $user->name = $request->name;
        $user->email = $request->email;
        if ($request->password) {
            $user->password = Hash::make($request->password);
        }
        $user->save();

        return redirect()->route('users.index');
    }

    public function deleteUser($id)
    {
        $user = User::findOrFail($id);
        $user->delete();

        return redirect()->route('users.index');
    }

    public function queueSettings()
    {
        $queueSettings = QueueSetting::all();
        return view('queueSettings', compact('queueSettings'));
    }

    public function addQueueSettings()
    {
        return view('addQueueSettings');
    }

    public function storeQueueSettings(Request $request)
    {
        QueueSetting::create([
            'nomor_loket' => $request->nomor_loket,
            'kode_antrean' => $request->kode_antrean,
            'keterangan' => $request->keterangan,
        ]);

        return redirect()->route('queue.settings');
    }

    public function editQueueSettings($id)
    {
        $queueSetting = QueueSetting::findOrFail($id);

        return view('editQueueSettings', compact('queueSetting'));
    }

    public function updateQueueSettings(Request $request)
    {
        $queueSetting = QueueSetting::findOrFail($request->id);

        $queueSetting->update([
            'nomor_loket' => $request->nomor_loket,
            'kode_antrean' => $request->kode_antrean,
            'keterangan' => $request->keterangan,
        ]);

        return redirect()->route('queue.settings');
    }

    public function deleteQueueSettings($id)
    {
        $queueSetting = QueueSetting::findOrFail($id);

        $queueSetting->delete();

        return redirect()->route('queue.settings');
    }

    public function printersIndex()
    {
        $printers = Printers::all();
        return view('printersIndex', compact('printers'));
    }

    public function addPrintersIndex()
    {
        $queueSettings = QueueSetting::all();
        return view('addPrintersIndex', compact('queueSettings'));
    }

    public function storePrintersIndex(Request $request)
    {
        $request->validate([
            'nama_printer' => 'required|string|max:255',
            'app_key' => 'required|string|max:255',
            'keterangan' => 'nullable|string',
        ]);

        Printers::create([
            'nama_printer' => $request->nama_printer,
            'app_key' => $request->app_key,
            'keterangan' => $request->keterangan,
        ]);

        return redirect()->route('printers.index');
    }

    public function editPrintersIndex($id)
    {
        $printer = Printers::findOrFail($id);
        $queueSettings = QueueSetting::all();
        return view('editPrintersIndex', compact('printer', 'queueSettings'));
    }

    public function updatePrintersIndex(Request $request, $id)
    {
        $request->validate([
            'nama_printer' => 'required|string|max:255',
            'app_key' => 'required|string|max:255',
            'keterangan' => 'nullable|string',
        ]);

        $printer = Printers::findOrFail($id);

        $printer->update([
            'nama_printer' => $request->nama_printer,
            'app_key' => $request->app_key,
            'keterangan' => $request->keterangan,
        ]);

        return redirect()->route('printers.index');
    }

    public function deletePrintersIndex($id)
    {
        $printer = Printers::findOrFail($id);
        $printer->delete();

        return redirect()->route('printers.index');
    }


    public function userContact()
    {
        return view('userContact');
    }


    //halaman untuk users
    public function userProfile()
    {
        $user = Auth::user();
        return view('userProfile', compact('user'));
    }

    public function userQueue()
    {
        return view('userQueue');
    }

    public function userUploadPhoto(Request $request)
    {
        $request->validate([
            'photo' => 'required|image|mimes:jpeg,png,jpg,gif|max:2048',
        ]);

        // Simpan foto di direktori yang ditentukan
        $imageName = time().'.'.$request->photo->extension();  
        $request->photo->move(public_path('profile_photos'), $imageName);

        // Simpan nama foto ke database
        $user = Auth::user();
        $user->photo = $imageName;
        $user->save();

        return redirect()->back()->with('success','Photo uploaded successfully.');
    }

    public function userEditPassword(Request $request)
    {
        $user = auth()->user();

        // Validasi input dari form
        $request->validate([
            'current_password' => 'required',
            'new_password' => 'required|min:6|different:current_password',
            'confirm_password' => 'required|same:new_password',
        ]);

        // Memeriksa apakah password saat ini benar
        if (!Hash::check($request->current_password, $user->password)) {
            return redirect()->back()->with('error', 'Password saat ini tidak cocok.');
        }

        // Menyimpan password baru ke dalam database
        $user->password = Hash::make($request->new_password);
        $user->save();

        return redirect()->back()->with('success', 'Password berhasil diubah.');
    }
}
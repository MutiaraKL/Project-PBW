<?php
  
namespace App\Http\Middleware;
  
use Closure;
use Illuminate\Http\Request;
use Illuminate\Http\Response; // Perbaiki penggunaan Response

class UserAccess
{
    /**
     * Handle an incoming request.
     *
     * @param  \Closure(\Illuminate\Http\Request): (\Illuminate\Http\Response)  $next // Perbaiki tipe balikan
     */
    public function handle(Request $request, Closure $next, $userType)
    {
        // Periksa apakah pengguna sudah login sebelum memeriksa tipe pengguna
        if(auth()->check() && auth()->user()->type == $userType){
            return $next($request);
        }
          
        return response()->json(['You do not have permission to access this page.'], 403); // Ubah respon jika tidak memiliki izin
    }
}

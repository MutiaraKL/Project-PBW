<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class QueueSetting extends Model
{
    use HasFactory;

    protected $table = 'queue_settings'; 
    protected $fillable = ['nomor_loket', 'kode_antrean', 'keterangan']; 
}

<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\HomeController;

Route::get('/', function () {
    return view('/auth.login');
});


Auth::routes();

// Rute untuk pengguna biasa
Route::middleware(['auth', 'user-access:user'])->group(function () {
    Route::get('/user/home', [HomeController::class, 'userHome'])->name('user.home');
    Route::get('/user/contact', [HomeController::class, 'userContact'])->name('user.contact');
    Route::get('/user/profile', [HomeController::class, 'userProfile'])->name('user.profile');
    Route::post('/user/upload-photo', [HomeController::class, 'userUploadPhoto'])->name('user.upload.photo');
    Route::post('/user/edit-password', [HomeController::class, 'userEditPassword'])->name('user.edit.password');
    Route::get('/user/queue', [HomeController::class, 'userQueue'])->name('user.queue');
});

// Rute untuk admin
Route::middleware(['auth', 'user-access:admin'])->group(function () {
    Route::get('/admin/home', [HomeController::class, 'adminHome'])->name('admin.home');
    Route::get('/admin/contact', [HomeController::class, 'adminContact'])->name('admin.contact');

    Route::get('/admin/profile', [HomeController::class, 'adminProfile'])->name('admin.profile');
    Route::post('/admin/upload-photo', [HomeController::class, 'adminUploadPhoto'])->name('admin.upload.photo');
    Route::post('/admin/edit-password', [HomeController::class, 'adminEditPassword'])->name('admin.edit.password');

    Route::get('/loket-details', [HomeController::class, 'loketDetails'])->name('loket.details');
    Route::get('/antarmuka-display', [HomeController::class, 'antarmukaDisplay'])->name('antarmuka.display');
    Route::get('/admin/print-queue', [HomeController::class, 'printQueue'])->name('admin.print.queue');
    Route::get('/reset-queue', [HomeController::class, 'resetQueue'])->name('reset.queue');
    Route::get('/antarmuka-antrean', [HomeController::class, 'antarmukaAntrean'])->name('antarmuka.antrean');
    Route::post('/call-queue/{queue}', [HomeController::class, 'callQueue'])->name('call.queue');
    Route::post('/repeat-call', [HomeController::class, 'repeatCall'])->name('repeat.call');

    Route::get('/users-index', [HomeController::class, 'usersIndex'])->name('users.index');
    Route::get('/add-users-index', [HomeController::class, 'addUsersIndex'])->name('add.users.index');
    Route::post('/store-users', [HomeController::class, 'storeUser'])->name('store.users');
    Route::get('/edit-users-index-{id}', [HomeController::class, 'editUsersIndex'])->name('edit.users.index');
    Route::post('/update-users-{id}', [HomeController::class, 'updateUser'])->name('update.users');
    Route::get('/delete-users-index-{id}', [HomeController::class, 'deleteUser'])->name('delete.users.index');
    
    Route::get('/queue-settings', [HomeController::class, 'queueSettings'])->name('queue.settings');
    Route::get('/add-queue-settings', [HomeController::class, 'addQueueSettings'])->name('add.queue.settings');
    Route::post('/store-queue-settings', [HomeController::class, 'storeQueueSettings'])->name('store.queue.settings');
    Route::get('/edit-queue-settings-{id}', [HomeController::class, 'editQueueSettings'])->name('edit.queue.settings');
    Route::post('/update-queue-settings', [HomeController::class, 'updateQueueSettings'])->name('update.queue.settings');
    Route::get('/queue-settings-{id}', [HomeController::class, 'deleteQueueSettings'])->name('delete.queue.settings');
    
    Route::get('/printers-index', [HomeController::class, 'printersIndex'])->name('printers.index');
    Route::get('/add-printers-index', [HomeController::class, 'addPrintersIndex'])->name('add.printers.index');
    Route::post('/store-printers-index', [HomeController::class, 'storePrintersIndex'])->name('store.printers.index');
    Route::get('/edit-printers-index-{id}', [HomeController::class, 'editPrintersIndex'])->name('edit.printers.index');
    Route::post('/update-printers-index-{id}', [HomeController::class, 'updatePrintersIndex'])->name('update.printers.index');
    Route::get('/delete-printers-index-{id}', [HomeController::class, 'deletePrintersIndex'])->name('delete.printers.index');
});

// Rute untuk manajer
Route::middleware(['auth', 'user-access:manager'])->group(function () {
    Route::get('/manager/home', [HomeController::class, 'managerHome'])->name('manager.home');
});

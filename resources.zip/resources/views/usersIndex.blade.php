@extends('layouts.adminApp')

@section('content')
<div class="container">
    <h2>Data Pengguna</h2>
    <div style="margin-bottom: 20px;">
        <a href="{{ route('add.users.index') }}" style="background-color: #0057FF; color: white; padding: 10px 20px; text-decoration: none; border-radius: 4px;">Tambah Data</a>
    </div>
    <table>
        <thead>
            <tr>
                <th style="text-align: center;">No</th>
                <th style="text-align: center;">Nama Pengguna</th> 
                <th style="text-align: center;">Email</th> 
                <th style="text-align: center;">Action</th>
            </tr>
        </thead>

        <tbody>
            @foreach($users as $key => $user)
            <tr>
                <td>{{ $key + 1 }}</td>
                <td>{{ $user->name }}</td>
                <td>{{ $user->email }}</td>
                <td style="text-align: center;">
                    <a href="{{ route('edit.users.index', ['id' => $user->id]) }}" class="btn btn-warning" style="width: 80px;">Edit</a>
                    <span onclick="confirmDelete('{{ $user->id }}')" class="btn btn-danger" style="width: 80px;">Delete</span>
                </td>
            </tr>
            @endforeach
        </tbody>
    </table>
    <script>
        function confirmDelete(userId) {
            if (confirm('Yakin menghapus data ini?')) {
                window.location.href = '/delete/users/index/' + userId;
            }
        }
    </script>
</div>
@endsection

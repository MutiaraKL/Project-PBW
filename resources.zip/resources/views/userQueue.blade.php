@extends('layouts.app2')

@section('content')
<div class="container">
    <h4 class="text-center mt-5 mb-4">Ambil Antrean Loket Apotek</h4>
    <hr class="mb-5">
    <div class="row justify-content-center">
        <div class="col-md-4">
            <div class="card mb-3" style="background-color: #08BCBC;">
                <div class="card-body text-center text-white">
                    <h5 class="card-title">Pengambilan Obat JKN/BPJS</h5>
                </div>
                <a class="text-center" style="color: white;">Print <i class="fa-solid fa-arrow-right"></i></a>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card mb-3" style="background-color: #08BCBC;">
                <div class="card-body text-center text-white">
                    <h5 class="card-title">Pengambilan Obat Umum</h5>
                </div>
                <a class="text-center" style="color: white;">Print <i class="fa-solid fa-arrow-right"></i></a>
            </div>
        </div>
    </div>
</div>
@endsection

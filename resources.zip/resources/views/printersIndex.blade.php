@extends('layouts.adminApp')

@section('content')
<div class="container">
    <h2>Data Printers</h2>
    <div style="margin-bottom: 20px;">
        <a href="{{ route('add.printers.index') }}" style="background-color: #0057FF; color: white; padding: 10px 20px; text-decoration: none; border-radius: 4px;">Tambah Data</a>
    </div>
    <table>
        <thead>
            <tr>
                <th style="text-align: center;">No</th>
                <th style="text-align: center;">Nama Printer</th> 
                <th style="text-align: center;">App Key</th>  
                <th style="text-align: center;">Keterangan</th> 
                <th style="text-align: center;">Action</th>
            </tr>
        </thead>

        <tbody>
        @foreach($printers as $printer)
            <tr>
                <td style="text-align: center;">{{ $loop->iteration }}</td>
                <td>{{ $printer->nama_printer }}</td>
                <td>{{ $printer->app_key }}</td>
                <td>{{ $printer->keterangan }}</td>
                <td style="text-align: center;">
                    <a href="{{ route('edit.printers.index', $printer->id) }}" class="btn btn-warning" style="width: 80px;">Edit</a>
                    <span onclick="confirmDelete('{{ $printer->id }}')" class="btn btn-danger" style="width: 80px;">Hapus</span>
                </td>
            </tr>
        @endforeach
        </tbody>
    </table>
    <script>
    function confirmDelete(printerId) {
        if (confirm('Yakin menghapus data ini?')) {
            window.location.href = '/delete/printers/index/' + printerId;
        }
    }
    </script>
</div>
@endsection

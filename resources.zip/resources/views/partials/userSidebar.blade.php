<nav id="sidebar">
    <div class="sidebar-header">
        <h4>Sistem Antrean Apotek RS. Prince Nayef</h4>
    </div>
    <div class="profile">
        <a href="{{ route('user.profile') }}" aria-label="Profile">
            <img src="{{ asset('profile_photos/' . Auth::user()->photo) }}" class="img-thumbnail rounded-circle">
            <h5>{{ Auth::user()->name }}</h5>
        </a>
    </div>
    <ul class="list-unstyled components">
        <li>
            <a href="{{ route('user.home') }}"><i class="fa-solid fa-gauge"></i> Dashboard</a>
        </li>
        <li>
            <a href="{{ route('user.profile') }}"><i class="fa-solid fa-user"></i> Profile</a>
        </li>
        <li>
            <a href="{{ route('logout') }}" class="logout" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
            <i class="fa-solid fa-right-from-bracket"></i> Logout
            </a>
            <form id="logout-form" action="{{ route('logout') }}" method="POST" class="d-none">
                @csrf
            </form>
        </li>
    </ul>
</nav>

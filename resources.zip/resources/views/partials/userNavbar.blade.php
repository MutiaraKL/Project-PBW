<!-- Navigasi -->
<nav class="navbar navbar-expand-lg">
    <div class="container">
        <div class="navbar-nav">
            <a class="nav-link" href="{{ route('user.home') }}">Home</a>
            <a class="nav-link" href="{{ route('user.contact') }}">Contact Us</a>
        </div>
    </div>
</nav>
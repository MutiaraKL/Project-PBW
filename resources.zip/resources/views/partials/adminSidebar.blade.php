<nav id="sidebar">
    <div class="sidebar-header">
        <h4>Sistem Antrean Apotek RS. Prince Nayef</h4>
    </div>
    <div class="profile">
        <a href="{{ route('admin.profile') }}" aria-label="Profile">
            <img src="{{ asset('profile_photos/' . Auth::user()->photo) }}" class="img-thumbnail rounded-circle">
            <h5>{{ Auth::user()->name }}</h5>
        </a>
    </div>
    <ul class="list-unstyled components">
        <li>
            <a href="{{ route('admin.home') }}"><i class="fa-solid fa-gauge"></i> Dashboard</a>
        </li>
        <li>
            <a href="{{ route('loket.details') }}"><i class="fa-solid fa-bars"></i></i> Rincian Loket</a>
        </li>
        <li>
            <a href="{{ route('users.index') }}"><i class="fa-solid fa-users"></i> Data Pengguna</a>
        </li>
        <li>
            <a href="{{ route('queue.settings') }}"><i class="fa-solid fa-database"></i> Data Pengaturan Antrean</a>
        </li>
        <li>
            <a href="{{ route('printers.index') }}"><i class="fa-solid fa-print"></i> Data Printer</a>
        </li>
        <li>
            <a href="{{ route('logout') }}" class="logout" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
            <i class="fa-solid fa-right-from-bracket"></i> Logout
            </a>
            <form id="logout-form" action="{{ route('logout') }}" method="POST" class="d-none">
                @csrf
            </form>
        </li>
    </ul>
</nav>

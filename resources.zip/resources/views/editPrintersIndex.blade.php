@extends('layouts.adminApp')

@section('content')
<div class="container">
    <h2>Edit Data Printer</h2>
    <form method="POST" action="{{ route('update.printers.index', $printer->id) }}">
        @csrf
        <div class="form-group">
            <label for="nama_printer">Nama Printer:</label>
            <input type="text" id="nama_printer" name="nama_printer" class="form-control" value="{{ $printer->nama_printer }}" required>
        </div>
        <div class="form-group">
            <label for="app_key">App Key:</label>
            <input type="text" id="app_key" name="app_key" class="form-control" value="{{ $printer->app_key }}" required>
        </div>
        <div class="form-group">
            <label for="keterangan">Keterangan:</label>
            <select id="keterangan" name="keterangan" class="form-control" required>
                <option value="">Pilih Printer</option>
                <option value="Printer Pengambilan Antrean">Printer Pengambilan Antrean</option>
                @foreach($queueSettings as $queueSetting)
                    <option value="{{ $queueSetting->id }}">{{ $queueSetting->nomor_loket }}</option>
                @endforeach
            </select>
        </div>
        <!-- Hidden field for passing ID -->
        <input type="hidden" name="id" value="{{ $printer->id }}">
        <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
        <a href="{{ route('printers.index') }}" class="btn btn-secondary btn-danger">Batal</a>
    </form>
</div>
@endsection
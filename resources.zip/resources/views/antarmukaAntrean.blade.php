<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistem Antrean Apotek RS. Prince Nayef</title>
    <style>
        h2 {
            text-align: center;
        }

        .container {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 10px;
        }

        .card {
            border: 1px solid #ccc;
            border-radius: 5px;
            padding: 10px;
            background-color: #00E0FF;
            width: calc(50% - 10px);
            margin-bottom: 10px;
        }

        @media (max-width: 600px) {
            .card {
                width: calc(100% - 10px);
                margin-right: 0;
            }
        }

        @media (min-width: 601px) {
            .card {
                width: calc(50% - 10px);
            }
        }
    </style>
</head>
<body>
    <h2>Sistem Antrean Apotek RS. Prince Nayef</h2>
    <div class="container">
        <!-- Card 1 -->
        <div class="card" id="card1">
            <h3>Loket 1</h3>
            <p id="queue1">-</p>
        </div>
        <!-- Card 2 -->
        <div class="card" id="card2">
            <h3>Loket 2</h3>
            <p id="queue2">-</p>
        </div>
        <!-- Card 3 -->
        <div class="card" id="card3">
            <h3>Loket 3</h3>
            <p id="queue3">-</p>
        </div>
        <!-- Card 4 -->
        <div class="card" id="card4">
            <h3>Loket 4</h3>
            <p id="queue4">-</p>
        </div>
    </div>
</body>
</html>

@extends('layouts.userApp')

@section('content')
<div class="container">
    <div class="contact-form">
        <h2>Contact Us</h2>
        <p>Punya pertanyaan atau butuh bantuan? Isi formulir di bawah ini untuk menghubungi kami.</p>
        <form action="/submitContactForm" method="post">
            @csrf
            <div class="form-group">
                <label for="name">Nama:</label>
                <input type="text" id="name" name="name" class="form-control" required>
            </div>
            <div class="form-group">
                <label for="email">Email:</label>
                <input type="email" id="email" name="email" class="form-control" required>
            </div>
            <div class="form-group">
                <label for="message">Pesan:</label>
                <textarea id="message" name="message" class="form-control" rows="5" required></textarea>
            </div>
            <button type="submit" class="btn btn-primary">Submit</button>
        </form>
    </div>
</div>
@endsection
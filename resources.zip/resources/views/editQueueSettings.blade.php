@extends('layouts.adminApp')

@section('content')
<div class="container">
    <h2>Edit Data Pengaturan Antrean</h2>
    <form method="POST" action="{{ route('update.queue.settings') }}">
        @csrf
        <div class="form-group">
            <label for="nomor_loket">Nomor Loket:</label>
            <input type="text" id="nomor_loket" name="nomor_loket" class="form-control" value="{{ $queueSetting->nomor_loket }}" required>
        </div>
        <div class="form-group">
            <label for="kode_antrean">Kode Antrean:</label>
            <select id="kode_antrean" name="kode_antrean" class="form-control" required>
                <option value="">Pilih Kode Antrean</option>
                <option value="A" {{ $queueSetting->kode_antrean == 'A' ? 'selected' : '' }}>A</option>
                <option value="B" {{ $queueSetting->kode_antrean == 'B' ? 'selected' : '' }}>B</option>
            </select>
        </div>
        <div class="form-group">
            <label for="keterangan">Keterangan:</label>
            <textarea id="keterangan" name="keterangan" class="form-control" required readonly>{{ $queueSetting->keterangan }}</textarea>
        </div>
        <!-- Hidden field for passing ID -->
        <input type="hidden" name="id" value="{{ $queueSetting->id }}">
        <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
        <a href="{{ route('queue.settings') }}" class="btn btn-secondary btn-danger">Batal</a>
    </form>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        const kodeAntrean = document.getElementById('kode_antrean');
        const keterangan = document.getElementById('keterangan');

        function updateKeterangan() {
            if (kodeAntrean.value === 'A') {
                keterangan.value = 'Umum';
            } else if (kodeAntrean.value === 'B') {
                keterangan.value = 'BPJS';
            } else {
                keterangan.value = '';
            }
        }

        // Initial update based on current value
        updateKeterangan();

        // Update keterangan on change
        kodeAntrean.addEventListener('change', updateKeterangan);
    });
</script>
@endsection

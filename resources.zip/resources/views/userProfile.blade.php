@extends('layouts.userApp')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-6 offset-md-3">
            <div class="card mt-5">
                <div class="card-body">
                    <div class="d-flex flex-column align-items-center mb-4">
                        <div class="mb-3">
                            <!-- Tampilkan foto profil -->
                            @if($user->photo)
                                <img src="{{ asset('profile_photos/' . $user->photo) }}" alt="Profile Photo" class="rounded-circle" width="100">
                            @else
                                <i class="fa-solid fa-circle-user fa-3x"></i>
                            @endif
                        </div>
                        <div>
                            <h4 class="text-muted mb-0 text-center">{{ $user->name }}</h4>
                            <p class="text-muted mb-0 text-center">{{ $user->email }}</p>
                        </div>
                    </div>

                    <ul class="list-group">
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                            Ubah Password
                            <!-- Icon edit -->
                            <a href="javascript:void(0)" onclick="togglePasswordForm()"><i class="fa-regular fa-pen-to-square"></i></a>
                        </li>
                    </ul>

                    <div class="card-body">
                        <!-- Form untuk mengedit password -->
                        <form id="password_form" action="{{ route('user.edit.password') }}" method="POST">
                            @csrf
                            <div class="form-group">
                                <label for="current_password">Password Sekarang:</label>
                                <input type="password" class="form-control" id="current_password" name="current_password" required>
                            </div>
                            <div class="form-group">
                                <label for="new_password">Password Baru:</label>
                                <input type="password" class="form-control" id="new_password" name="new_password" required>
                            </div>
                            <div class="form-group">
                                <label for="confirm_password">Konfirmasi Password Baru:</label>
                                <input type="password" class="form-control" id="confirm_password" name="confirm_password" required>
                            </div>
                            <button type="submit" class="btn btn-primary">Simpan Password</button>
                        </form>
                    </div>
                </div>
            </div>
            
            <div class="card mt-3">
                <div class="card-body">
                    <!-- Form untuk mengunggah foto profil -->
                    <form action="{{ route('user.upload.photo') }}" method="POST" enctype="multipart/form-data">
                        @csrf
                        <div class="form-group">
                            <label for="photo">Unggah Foto:</label>
                            <input type="file" class="form-control-file" id="photo" name="photo">
                        </div>
                        <button type="submit" class="btn btn-primary">Unggah</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    function togglePasswordForm() {
        var passwordForm = document.getElementById('password_form');
        if (passwordForm.style.display === "" || passwordForm.style.display === "none") {
            passwordForm.style.display = "block";
        } else {
            passwordForm.style.display = "none";
        }
    }
</script>

@endsection

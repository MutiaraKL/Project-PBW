<!doctype html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>{{ ('Sistem Antrean Apotek RS. Prince Nayef') }}</title>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=Nunito" rel="stylesheet">

    <!-- Scripts -->
    @vite(['resources/sass/app.scss', 'resources/js/app.js'])

    <!-- ikon -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/js/all.min.js" rel="stylesheet"/>
</head>
<body>
    <div id="app" class="d-flex">
        <div class="d-flex flex-column flex-shrink-0" style="width: 250px;">
            @include('partials.adminSidebar')
        </div>
        <div class="flex-grow-1">
            @include('partials.adminNavbar')
            <main class="py-4">
                @yield('content')
            </main>
        </div>
    </div>
</body>
</html>

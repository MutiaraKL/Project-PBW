@extends('layouts.adminApp')

@section('content')
<div class="container">
    <h2>Data Pengaturan Antrean</h2>
    <div style="margin-bottom: 20px;">
        <a href="{{ route('add.queue.settings') }}" style="background-color: #0057FF; color: white; padding: 10px 20px; text-decoration: none; border-radius: 4px;">Tambah Data</a>
    </div>
    <table>
        <thead>
            <tr>
                <th style="text-align: center;">No</th>
                <th style="text-align: center;">Nomor Loket</th> 
                <th style="text-align: center;">Kode Antrean</th>  
                <th style="text-align: center;">Keterangan</th> 
                <th style="text-align: center;">Action</th>
            </tr>
        </thead>

        <tbody>
        @foreach($queueSettings as $queueSetting)
            <tr>
                <td style="text-align: center;">{{ $loop->iteration }}</td>
                <td>{{ $queueSetting->nomor_loket }}</td>
                <td>{{ $queueSetting->kode_antrean }}</td>
                <td>{{ $queueSetting->keterangan }}</td>
                <td style="text-align: center;">
                    <a href="{{ route('edit.queue.settings', $queueSetting->id) }}" class="btn btn-warning" style="width: 80px;">Edit</a>
                    <span onclick="confirmDelete('{{ $queueSetting->id }}')" class="btn btn-danger" style="width: 80px;">Hapus</span>
                </td>
            </tr>
            @endforeach
        </tbody>
    </table>
    <script>
    function confirmDelete(queueSettingId) {
        if (confirm('Yakin menghapus data ini?')) {
            window.location.href = '/queue/settings/' + queueSettingId;
        }
    }
</script>
</div>
@endsection

@extends('layouts.app2')
  
@section('content')
<div class="container">
    <div class="row">
        <!-- Column for queues -->
        <div class="col-md-8">
            <table>
                <tr>
                    <th colspan="3">Antrean Aktif</th>
                </tr>
                <tr>
                    <td>
                        <table>
                            <thead>
                                <tr>
                                    <th>Nomor Antrean</th>
                                    <th>Nomor Loket</th>
                                    <th>Jenis Transaksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <!-- Loop through active queues and display -->
                                @foreach($activeQueues as $queue)
                                <tr>
                                    <td>{{ $queue->nomor_antrean }}</td>
                                    <td>{{ $queue->nomor_loket }}</td>
                                    <td>{{ $queue->jenis_transaksi }}</td>
                                </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </td>
                </tr>
            </table>
        
            <table>
                <tr>
                    <th colspan="3">Antrean Belum Dipanggil</th>
                </tr>
                <tr>
                    <td>
                        <table>
                            <thead>
                                <tr>
                                    <th>Nomor Antrean</th>
                                    <th>Nomor Loket</th>
                                    <th>Jenis Transaksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <!-- Loop through queues not called yet and display -->
                                @foreach($queuesNotCalled as $queue)
                                <tr>
                                    <td>{{ $queue->nomor_antrean }}</td>
                                    <td>{{ $queue->nomor_loket }}</td>
                                    <td>{{ $queue->jenis_transaksi }}</td>
                                </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </td>
                </tr>
            </table>
        </div>

        <!-- Column for actions and user details -->
        <div class="col-md-4">
        <table>
            <thead>
                <tr>
                    <th colspan="3">Action</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td style="text-align: center;">
                        <button onclick="callQueue({{ $queue->id }})" style="background-color: #0057FF;">Panggil Antrean</button>
                        <button onclick="repeatCall()" style="background-color: #219305;">Ulangi Pemanggilan</button>
                    </td>
                </tr>
            </tbody>
        </table>
        
        <table>
            <thead>
                <tr>
                    <th colspan="3">Detail Loket</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td style="text-align: center;">
                    <img src="{{ asset('profile_photos/' . Auth::user()->photo) }}" class="img-thumbnail rounded-circle">
                        <p>{{ $user->name }}</p>
                        <p>{{ $user->email }}</p>
                        <p>Nomor Loket: 1 </p>
                        <p>Jenis Loket: Umum </p>
                        <button onclick="window.location='{{ route('admin.home') }}'" style="background-color: #219305;">Kembali ke Dashboard</button>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
</div>
@endsection

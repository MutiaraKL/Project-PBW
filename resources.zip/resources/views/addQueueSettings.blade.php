@extends('layouts.adminApp')

@section('content')
<div class="container">
    <h2>Tambah Data Pengaturan Antrean</h2>
    <form method="POST" action="{{ route('store.queue.settings') }}">
        @csrf
        <div class="form-group">
            <label for="nomor_loket">Nomor Loket:</label>
            <input type="text" id="nomor_loket" name="nomor_loket" class="form-control" required>
        </div>
        <div class="form-group">
            <label for="kode_antrean">Kode Antrean:</label>
            <select id="kode_antrean" name="kode_antrean" class="form-control" required>
                <option value="">Pilih Kode Antrean</option>
                <option value="A">A</option>
                <option value="B">B</option>
            </select>
        </div>
        <div class="form-group">
            <label for="keterangan">Keterangan:</label>
            <textarea id="keterangan" name="keterangan" class="form-control" required readonly></textarea>
        </div>
        <button type="submit" class="btn btn-primary">Simpan</button>
        <a href="{{ route('queue.settings') }}" class="btn btn-secondary btn-danger">Batal</a>
    </form>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        const kodeAntrean = document.getElementById('kode_antrean');
        const keterangan = document.getElementById('keterangan');

        kodeAntrean.addEventListener('change', function() {
            if (kodeAntrean.value === 'A') {
                keterangan.value = 'Umum';
            } else if (kodeAntrean.value === 'B') {
                keterangan.value = 'BPJS';
            } else {
                keterangan.value = '';
            }
        });
    });
</script>
@endsection

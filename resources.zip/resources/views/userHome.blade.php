@extends('layouts.userApp')
  
@section('content')
<div class="container">
    <div>
        <h2><strong>Dashboard</strong></h2>

        <div class="row">
            <div class="col-md-4">
                <div class="card mb-3" style="background-color: #00E0FF;">
                    <div class="card-body text-center">
                        <h5>Riwayat Berobat</h5>
                    </div>
                    <a class="text-center" style="color: inherit;">Info lebih lanjut <i class="fa-solid fa-arrow-right"></i></a>
                </div>
            </div>

            <div class="col-md-4">
                <div class="card mb-3" style="background-color: #71CD59;">
                    <div class="card-body text-center">
                        <h5>Ambil Antrean Loket Berobat</h5>
                    </div>
                    <a class="text-center" style="color: inherit;">Info lebih lanjut <i class="fa-solid fa-arrow-right"></i></a>
                </div>
            </div>

            <div class="col-md-4">
                <div class="card mb-3" style="background-color: #08BCBC;">
                    <div class="card-body text-center">
                        <h5>Ambil Antrean Loket Apotek</h5>
                    </div>
                        <a href="{{ route('user.queue') }}" class="text-center" style="color: inherit;">Info lebih lanjut <i class="fa-solid fa-arrow-right"></i></a>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

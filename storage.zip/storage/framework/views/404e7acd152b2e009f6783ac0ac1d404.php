

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <h4><strong>Dashboard</strong></h4>
            <div class="row">
                <div class="col-md-4">
                    <div class="card mb-4" style="background-color: #F5F5F5;">
                        <div class="card-body">
                            <div style="background-color: #08BCBC; width: 60px; height: 60px; float: left; margin-right: 10px;">
                                <i class="fa-regular fa-bookmark fa-3x" style="margin:10px; margin-left:15px; color: white;"></i>
                            </div>
                            <h5 class="card-title">Total Antrean</h5>
                            <p class="card-text"><?php echo e($totalAntrean); ?></p>
                        </div>
                    </div>
                </div>

                <div class="col-md-4">
                    <div class="card mb-4" style="background-color: #F5F5F5;">
                        <div class="card-body">
                            <div style="background-color: #FF1321; width: 60px; height: 60px; float: left; margin-right: 10px;">
                                <i class="fa-solid fa-table-cells-large fa-3x" style="margin:9px; color: white;"></i>
                            </div>
                            <h5 class="card-title">Total Loket</h5>
                            <p class="card-text"><?php echo e($totalLoket); ?></p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card mb-4" style="background-color: #F5F5F5;">
                        <div class="card-body">
                            <div style="background-color: #219305; width: 60px; height: 60px; float: left; margin-right: 10px;">
                                <i class="fa-regular fa-user fa-3x" style="margin:10px; color: white;"></i>
                            </div>
                            <h5 class="card-title">Total Pengguna</h5>
                            <p class="card-text"><?php echo e($totalPengguna); ?></p>
                        </div>
                    </div>
                </div>
            </div>

            <h5 class="mt-5"><strong>Tools Antrean</strong></h5>
            <div class="row">
                <div class="col-md-4">
                    <div class="card mb-4" style="background-color: #EE0C19;">
                        <div class="card-body">
                            <i class="fa-solid fa-bookmark fa-4x" style="float: right; margin-left: 10px; color: #6E191E"></i>
                            <h5 class="card-title white-text">Reset Antrean</h5>
                        </div>
                        <a href="<?php echo e(route('reset.queue')); ?>" class="text-center" style="color: white;">Reset <i class="fa-solid fa-arrow-right"></i></a>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card mb-4" style="background-color: #08BCBC;">
                        <div class="card-body">
                            <i class="fa-solid fa-bookmark fa-4x" style="float: right; margin-left: 10px; color: #0D6565"></i>
                            <h5 class="card-title white-text">Antarmuka Antrean</h5>
                        </div>
                        <a href="<?php echo e(route('antarmuka.antrean')); ?>" class="text-center" style="color: white;">Info lebih lanjut <i class="fa-solid fa-arrow-right"></i></a>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card mb-4" style="background-color: #219305;">
                        <div class="card-body">
                            <i class="fa-solid fa-bookmark fa-4x" style="float: right; margin-left: 10px; color: #1C530E"></i>
                            <h5 class="card-title white-text">Antarmuka Display</h5>
                        </div>
                        <a href="<?php echo e(route('antarmuka.display')); ?>" class="text-center" style="color: white;">Info lebih lanjut <i class="fa-solid fa-arrow-right"></i></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminApp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project_laravel\resources\views/adminHome.blade.php ENDPATH**/ ?>
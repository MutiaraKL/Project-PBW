<nav id="sidebar">
    <div class="sidebar-header">
        <h4>Sistem Antrean Apotek RS. Prince Nayef</h4>
    </div>
    <div class="profile">
        <a href="<?php echo e(route('admin.profile')); ?>" aria-label="Profile">
            <img src="<?php echo e(asset('profile_photos/' . Auth::user()->photo)); ?>" class="img-thumbnail rounded-circle">
            <h5><?php echo e(Auth::user()->name); ?></h5>
        </a>
    </div>
    <ul class="list-unstyled components">
        <li>
            <a href="<?php echo e(route('admin.home')); ?>"><i class="fa-solid fa-gauge"></i> Dashboard</a>
        </li>
        <li>
            <a href="<?php echo e(route('loket.details')); ?>"><i class="fa-solid fa-bars"></i></i> Rincian Loket</a>
        </li>
        <li>
            <a href="<?php echo e(route('users.index')); ?>"><i class="fa-solid fa-users"></i> Data Pengguna</a>
        </li>
        <li>
            <a href="<?php echo e(route('queue.settings')); ?>"><i class="fa-solid fa-database"></i> Data Pengaturan Antrean</a>
        </li>
        <li>
            <a href="<?php echo e(route('printers.index')); ?>"><i class="fa-solid fa-print"></i> Data Printer</a>
        </li>
        <li>
            <a href="<?php echo e(route('logout')); ?>" class="logout" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
            <i class="fa-solid fa-right-from-bracket"></i> Logout
            </a>
            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                <?php echo csrf_field(); ?>
            </form>
        </li>
    </ul>
</nav>
<?php /**PATH C:\xampp\htdocs\project_laravel\resources\views/partials/adminSidebar.blade.php ENDPATH**/ ?>

  
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <!-- Column for queues -->
        <div class="col-md-8">
            <table>
                <tr>
                    <th colspan="3">Antrean Aktif</th>
                </tr>
                <tr>
                    <td>
                        <table>
                            <thead>
                                <tr>
                                    <th>Nomor Antrean</th>
                                    <th>Nomor Loket</th>
                                    <th>Jenis Transaksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <!-- Loop through active queues and display -->
                                <?php $__currentLoopData = $activeQueues; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $queue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($queue->nomor_antrean); ?></td>
                                    <td><?php echo e($queue->nomor_loket); ?></td>
                                    <td><?php echo e($queue->jenis_transaksi); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </td>
                </tr>
            </table>
        
            <table>
                <tr>
                    <th colspan="3">Antrean Belum Dipanggil</th>
                </tr>
                <tr>
                    <td>
                        <table>
                            <thead>
                                <tr>
                                    <th>Nomor Antrean</th>
                                    <th>Nomor Loket</th>
                                    <th>Jenis Transaksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <!-- Loop through queues not called yet and display -->
                                <?php $__currentLoopData = $queuesNotCalled; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $queue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($queue->nomor_antrean); ?></td>
                                    <td><?php echo e($queue->nomor_loket); ?></td>
                                    <td><?php echo e($queue->jenis_transaksi); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </td>
                </tr>
            </table>
        </div>

        <!-- Column for actions and user details -->
        <div class="col-md-4">
        <table>
            <thead>
                <tr>
                    <th colspan="3">Action</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td style="text-align: center;">
                        <button onclick="callQueue(<?php echo e($queue->id); ?>)" style="background-color: #0057FF;">Panggil Antrean</button>
                        <button onclick="repeatCall()" style="background-color: #219305;">Ulangi Pemanggilan</button>
                    </td>
                </tr>
            </tbody>
        </table>
        
        <table>
            <thead>
                <tr>
                    <th colspan="3">Detail Loket</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td style="text-align: center;">
                    <img src="<?php echo e(asset('profile_photos/' . Auth::user()->photo)); ?>" class="img-thumbnail rounded-circle">
                        <p><?php echo e($user->name); ?></p>
                        <p><?php echo e($user->email); ?></p>
                        <p>Nomor Loket: 1 </p>
                        <p>Jenis Loket: Umum </p>
                        <button onclick="window.location='<?php echo e(route('admin.home')); ?>'" style="background-color: #219305;">Kembali ke Dashboard</button>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project_laravel\resources\views/loketdetails.blade.php ENDPATH**/ ?>


<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>Data Pengguna</h2>
    <div style="margin-bottom: 20px;">
        <a href="<?php echo e(route('add.users.index')); ?>" style="background-color: #0057FF; color: white; padding: 10px 20px; text-decoration: none; border-radius: 4px;">Tambah Data</a>
    </div>
    <table>
        <thead>
            <tr>
                <th style="text-align: center;">No</th>
                <th style="text-align: center;">Nama Pengguna</th> 
                <th style="text-align: center;">Email</th> 
                <th style="text-align: center;">Action</th>
            </tr>
        </thead>

        <tbody>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($key + 1); ?></td>
                <td><?php echo e($user->name); ?></td>
                <td><?php echo e($user->email); ?></td>
                <td style="text-align: center;">
                    <a href="<?php echo e(route('edit.users.index', ['id' => $user->id])); ?>" class="btn btn-warning" style="width: 80px;">Edit</a>
                    <span onclick="confirmDelete('<?php echo e($user->id); ?>')" class="btn btn-danger" style="width: 80px;">Delete</span>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <script>
        function confirmDelete(userId) {
            if (confirm('Yakin menghapus data ini?')) {
                window.location.href = '/delete/users/index/' + userId;
            }
        }
    </script>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminApp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project_laravel\resources\views/usersIndex.blade.php ENDPATH**/ ?>
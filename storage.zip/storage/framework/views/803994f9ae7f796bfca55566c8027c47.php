

<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>Tambah Data Printer</h2>
    <form method="POST" action="<?php echo e(route('store.printers.index')); ?>">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="nama_printer">Nama Printer:</label>
            <input type="text" id="nama_printer" name="nama_printer" class="form-control" required>
        </div>
        <div class="form-group">
            <label for="app_key">App Key:</label>
            <input type="text" id="app_key" name="app_key" class="form-control" required>
        </div>
        <div class="form-group">
            <label for="keterangan">Keterangan:</label>
            <select id="keterangan" name="keterangan" class="form-control" required>
                <option value="">Pilih Printer</option>
                <option value="Printer Pengambilan Antrean">Printer Pengambilan Antrean</option>
                <?php $__currentLoopData = $queueSettings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $queueSetting): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($queueSetting->id); ?>"><?php echo e($queueSetting->nomor_loket); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <button type="submit" class="btn btn-primary">Simpan</button>
        <a href="<?php echo e(route('printers.index')); ?>" class="btn btn-secondary btn-danger">Batal</a>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminApp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project_laravel\resources\views/addPrintersIndex.blade.php ENDPATH**/ ?>
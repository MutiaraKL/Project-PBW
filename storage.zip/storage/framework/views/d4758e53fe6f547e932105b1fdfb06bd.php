<nav id="sidebar">
    <div class="sidebar-header">
        <h4>Sistem Antrean Apotek RS. Prince Nayef</h4>
    </div>
    <div class="profile">
        <a href="<?php echo e(route('user.profile')); ?>" aria-label="Profile">
            <img src="<?php echo e(asset('profile_photos/' . Auth::user()->photo)); ?>" class="img-thumbnail rounded-circle">
            <h5><?php echo e(Auth::user()->name); ?></h5>
        </a>
    </div>
    <ul class="list-unstyled components">
        <li>
            <a href="<?php echo e(route('user.home')); ?>"><i class="fa-solid fa-gauge"></i> Dashboard</a>
        </li>
        <li>
            <a href="<?php echo e(route('user.profile')); ?>"><i class="fa-solid fa-user"></i> Profile</a>
        </li>
        <li>
            <a href="<?php echo e(route('logout')); ?>" class="logout" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
            <i class="fa-solid fa-right-from-bracket"></i> Logout
            </a>
            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                <?php echo csrf_field(); ?>
            </form>
        </li>
    </ul>
</nav>
<?php /**PATH C:\xampp\htdocs\project_laravel\resources\views/partials/userSidebar.blade.php ENDPATH**/ ?>
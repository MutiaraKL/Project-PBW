

<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>Data Printers</h2>
    <div style="margin-bottom: 20px;">
        <a href="<?php echo e(route('add.printers.index')); ?>" style="background-color: #0057FF; color: white; padding: 10px 20px; text-decoration: none; border-radius: 4px;">Tambah Data</a>
    </div>
    <table>
        <thead>
            <tr>
                <th style="text-align: center;">No</th>
                <th style="text-align: center;">Nama Printer</th> 
                <th style="text-align: center;">App Key</th>  
                <th style="text-align: center;">Keterangan</th> 
                <th style="text-align: center;">Action</th>
            </tr>
        </thead>

        <tbody>
        <?php $__currentLoopData = $printers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $printer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td style="text-align: center;"><?php echo e($loop->iteration); ?></td>
                <td><?php echo e($printer->nama_printer); ?></td>
                <td><?php echo e($printer->app_key); ?></td>
                <td><?php echo e($printer->keterangan); ?></td>
                <td style="text-align: center;">
                    <a href="<?php echo e(route('edit.printers.index', $printer->id)); ?>" class="btn btn-warning" style="width: 80px;">Edit</a>
                    <span onclick="confirmDelete('<?php echo e($printer->id); ?>')" class="btn btn-danger" style="width: 80px;">Hapus</span>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <script>
    function confirmDelete(printerId) {
        if (confirm('Yakin menghapus data ini?')) {
            window.location.href = '/delete/printers/index/' + printerId;
        }
    }
    </script>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminApp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project_laravel\resources\views/printersIndex.blade.php ENDPATH**/ ?>
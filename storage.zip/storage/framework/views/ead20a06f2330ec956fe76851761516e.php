

<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>Data Pengaturan Antrean</h2>
    <div style="margin-bottom: 20px;">
        <a href="<?php echo e(route('add.queue.settings')); ?>" style="background-color: #0057FF; color: white; padding: 10px 20px; text-decoration: none; border-radius: 4px;">Tambah Data</a>
    </div>
    <table>
        <thead>
            <tr>
                <th style="text-align: center;">No</th>
                <th style="text-align: center;">Nomor Loket</th> 
                <th style="text-align: center;">Kode Antrean</th>  
                <th style="text-align: center;">Keterangan</th> 
                <th style="text-align: center;">Action</th>
            </tr>
        </thead>

        <tbody>
        <?php $__currentLoopData = $queueSettings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $queueSetting): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td style="text-align: center;"><?php echo e($loop->iteration); ?></td>
                <td><?php echo e($queueSetting->nomor_loket); ?></td>
                <td><?php echo e($queueSetting->kode_antrean); ?></td>
                <td><?php echo e($queueSetting->keterangan); ?></td>
                <td style="text-align: center;">
                    <a href="<?php echo e(route('edit.queue.settings', $queueSetting->id)); ?>" class="btn btn-warning" style="width: 80px;">Edit</a>
                    <span onclick="confirmDelete('<?php echo e($queueSetting->id); ?>')" class="btn btn-danger" style="width: 80px;">Hapus</span>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <script>
    function confirmDelete(queueSettingId) {
        if (confirm('Yakin menghapus data ini?')) {
            window.location.href = '/queue/settings/' + queueSettingId;
        }
    }
</script>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminApp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project_laravel\resources\views/queueSettings.blade.php ENDPATH**/ ?>
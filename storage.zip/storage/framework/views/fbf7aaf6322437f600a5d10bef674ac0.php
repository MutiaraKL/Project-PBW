<!-- Navigasi -->
<nav class="navbar navbar-expand-lg navbar-custom">
    <div class="container d-flex justify-content-between align-items-center">
        <div class="left-content d-flex align-items-center">
            <img src="<?php echo e(asset('images/prince-nayef.png')); ?>" alt="Logo RS" class="logo">
            <h4 class="ml-2 mb-0">RS PENDIDIKAN PRINCE NAYEF</h4>
        </div>
        <div class="right-content">
            <h4 id="date-time">Tanggal: <span id="date"></span> | <span id="time"></span></h4>
        </div>
    </div>
</nav>

<script>
    function updateTime() {
        var now = new Date();
        var date = now.toLocaleDateString('id-ID', {day: '2-digit', month: '2-digit', year: 'numeric'});
        var time = now.toLocaleTimeString('id-ID', {hour: '2-digit', minute: '2-digit', second: '2-digit'});
        document.getElementById('date').textContent = date;
        document.getElementById('time').textContent = time;
    }

    updateTime();
    setInterval(updateTime, 1000);
</script>
<?php /**PATH C:\xampp\htdocs\project_laravel\resources\views/partials/navbar.blade.php ENDPATH**/ ?>
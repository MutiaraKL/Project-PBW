<!-- Navigasi -->
<nav class="navbar navbar-expand-lg">
    <div class="container">
        <div class="navbar-nav">
            <a class="nav-link" href="<?php echo e(route('admin.home')); ?>">Home</a>
            <a class="nav-link" href="<?php echo e(route('admin.contact')); ?>">Contact Us</a>
        </div>
    </div>
</nav><?php /**PATH C:\xampp\htdocs\project_laravel\resources\views/partials/adminNavbar.blade.php ENDPATH**/ ?>